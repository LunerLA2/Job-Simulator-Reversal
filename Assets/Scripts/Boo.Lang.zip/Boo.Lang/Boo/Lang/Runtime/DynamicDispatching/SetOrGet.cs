namespace Boo.Lang.Runtime.DynamicDispatching
{
	internal enum SetOrGet
	{
		Set = 0,
		Get = 1
	}
}
