namespace Boo.Lang.Runtime.DynamicDispatching
{
	public delegate object Dispatcher(object target, object[] args);
}
