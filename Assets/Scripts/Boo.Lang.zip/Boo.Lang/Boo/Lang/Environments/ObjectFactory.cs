namespace Boo.Lang.Environments
{
	public delegate object ObjectFactory();
}
