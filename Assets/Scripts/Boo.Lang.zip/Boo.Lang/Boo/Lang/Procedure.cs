namespace Boo.Lang
{
	public delegate void Procedure();
}
