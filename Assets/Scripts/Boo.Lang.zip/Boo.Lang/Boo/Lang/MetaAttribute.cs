using System;

namespace Boo.Lang
{
	[Serializable]
	[AttributeUsage(AttributeTargets.Method)]
	public class MetaAttribute : Attribute
	{
	}
}
