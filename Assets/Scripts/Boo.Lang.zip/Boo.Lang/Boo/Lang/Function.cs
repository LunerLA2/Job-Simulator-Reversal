namespace Boo.Lang
{
	public delegate TResult Function<in T1, out TResult>(T1 arg);
}
