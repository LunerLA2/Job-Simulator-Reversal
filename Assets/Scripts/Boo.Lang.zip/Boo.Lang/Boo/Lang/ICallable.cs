namespace Boo.Lang
{
	public interface ICallable
	{
		object Call(object[] args);
	}
}
